import csv
import os

# Function to read the column A (words) from CSV and return as a list of words
def read_column(file_path):
    words = []
    with open(file_path, mode='r', newline='', encoding='utf-8') as csvfile:
        csvreader = csv.reader(csvfile)
        next(csvreader)  # Skip the header (first row)
        for row in csvreader:
            if row:  # Ensure the row is not empty
                words.append(row[0])  # Only take the word from Column A
    return words

# Function to format the CSV content as a string
def format_csv_content(file_path):
    content = []
    with open(file_path, mode='r', newline='', encoding='utf-8') as csvfile:
        csvreader = csv.reader(csvfile)
        for row in csvreader:
            content.append(", ".join(row))  # Join the columns with commas for each row
    return "\n".join(content)  # Join all rows by new lines

# Function to write content and the sentences to a text file
def write_to_text_file(output_file, content1, content2, content3, sentence1, sentence2, sentence3, transcription):
    with open(output_file, mode='w', encoding='utf-8') as textfile:
        # Write the content of the first CSV file
        textfile.write(content1)
        textfile.write("\n\n")  # Add space between the CSV contents
        # Write the content of the second CSV file
        textfile.write(content2)
        textfile.write("\n\n")  # Add space between CSV content
        # Write the content of the third CSV file
        textfile.write(content3)
        textfile.write("\n\n")  # Add space between CSV and sentences
        
        # Write the sentences for WHLV2, WLV2, and third sentence
        textfile.write(f"WHLV2: {sentence1}\n")
        textfile.write(f"WLV2: {sentence2}\n")
        textfile.write(f"Third Sentence: {sentence3}\n")
        
        # Write the transcription found in the text file
        textfile.write(f"\nIndicConformer: {transcription}\n")

# Function to search for the transcription corresponding to the filename (with .mp3 or .wav) in the transcription text file
def find_transcription(transcription_file_path, csv_filename):
    # Get the base name without extension (.csv)
    base_filename = os.path.splitext(csv_filename)[0]
    
    # Create the possible filenames with .mp3 and .wav extensions
    mp3_filename = f"{base_filename}.mp3"
    wav_filename = f"{base_filename}.wav"
    
    with open(transcription_file_path, mode='r', encoding='utf-8') as transcription_file:
        lines = transcription_file.readlines()
        
        # Search for the base name with .mp3 or .wav extension, including colon and space
        for i, line in enumerate(lines):
            # Strip leading/trailing spaces, and check if the line starts with the filename followed by a colon
            if line.strip().startswith(mp3_filename + ":") or line.strip().startswith(wav_filename + ":"):
                # If the filename is found, return the transcription (the text after the colon)
                transcription = line.split(":", 1)[1].strip() if len(line.split(":", 1)) > 1 else "No transcription found."
                return transcription
    return "No transcription found."  # If filename not found


# Function to process CSV files from three directories and save the result in the output directory
def process_csv_files(input_dir1, input_dir2, input_dir3, output_dir, transcription_file_path):
    # Get the list of CSV files in the first directory
    csv_files = os.listdir(input_dir1)
    
    # Ensure the output directory exists
    os.makedirs(output_dir, exist_ok=True)

    for csv_file in csv_files:
        # Ensure the files exist in all three directories
        file1_path = os.path.join(input_dir1, csv_file)
        file2_path = os.path.join(input_dir2, csv_file)
        file3_path = os.path.join(input_dir3, csv_file)
        
        if os.path.exists(file1_path) and os.path.exists(file2_path) and os.path.exists(file3_path):
            # Read the column A (words) from all three CSV files
            words1 = read_column(file1_path)
            words2 = read_column(file2_path)
            words3 = read_column(file3_path)

            # Create sentences from the list of words (exclude the first word and join the rest)
            sentence1 = " ".join(words1[0:])  # Skip the first word and join the rest
            sentence2 = " ".join(words2[0:])  # Skip the first word and join the rest
            sentence3 = " ".join(words3[0:])  # Skip the first word and join the rest

            # Format the content of all three CSV files as strings (including all columns)
            content1 = format_csv_content(file1_path)
            content2 = format_csv_content(file2_path)
            content3 = format_csv_content(file3_path)

            # Search for transcription in the transcription file
            transcription = find_transcription(transcription_file_path, csv_file)

            # Generate output file path (change extension to .txt)
            output_file = os.path.join(output_dir, f"{os.path.splitext(csv_file)[0]}.txt")

            # Write the content and sentences to the text file
            write_to_text_file(output_file, content1, content2, content3, sentence1, sentence2, sentence3, transcription)

            print(f"Processed {csv_file}. Output written to {output_file}")

def main():
    # Define the directories for input, output and the transcription file path
    input_dir1 = '/home/pc/Desktop/Timestamps/Outputs/Output_WHLV2/csv_files'
    input_dir2 = '/home/pc/Desktop/Timestamps/Outputs/Output_WLV2/csv_files'
    input_dir3 = '/home/pc/Desktop/Timestamps/Outputs/IndicConformer'  # Added third directory
    output_dir = '/home/pc/Desktop/Timestamps/Collaboration'
    transcription_file_path = '/home/pc/Desktop/IndicConformer/predicted_transcript.txt'

    # Process the CSV files from all three directories and generate the output files
    process_csv_files(input_dir1, input_dir2, input_dir3, output_dir, transcription_file_path)

if __name__ == '__main__':
    main()

