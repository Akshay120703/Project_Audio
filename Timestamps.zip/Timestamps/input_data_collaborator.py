import csv
import os

# Function to read the column A (words) from CSV and return as a list of words
def read_column(file_path):
    words = []
    with open(file_path, mode='r', newline='', encoding='utf-8') as csvfile:
        csvreader = csv.reader(csvfile)
        next(csvreader)  # Skip the header (first row)
        for row in csvreader:
            if row:  # Ensure the row is not empty
                words.append(row[0])  # Only take the word from Column A
    return words

# Function to format the CSV content as a string
def format_csv_content(file_path):
    content = []
    with open(file_path, mode='r', newline='', encoding='utf-8') as csvfile:
        csvreader = csv.reader(csvfile)
        for row in csvreader:
            content.append(", ".join(row))  # Join the columns with commas for each row
    return "\n".join(content)  # Join all rows by new lines

# Function to write content and the sentences to a text file
def write_to_text_file(output_file, content1, content2, sentence1, sentence2):
    with open(output_file, mode='w', encoding='utf-8') as textfile:
        # Write the content of the first CSV file
        textfile.write(content1)
        textfile.write("\n\n")  # Add space between the two CSV contents
        # Write the content of the second CSV file
        textfile.write(content2)
        textfile.write("\n\n")  # Add space between CSV and sentences
        
        # Write the sentences for WHLV2 and WLV2
        textfile.write(f"WHLV2: {sentence1}\n")
        textfile.write(f"WLV2: {sentence2}\n")

# Function to process CSV files from two directories and save the result in the output directory
def process_csv_files(input_dir1, input_dir2, output_dir):
    # Get the list of CSV files in the first directory
    csv_files = os.listdir(input_dir1)
    
    # Ensure the output directory exists
    os.makedirs(output_dir, exist_ok=True)

    for csv_file in csv_files:
        # Ensure the files exist in both directories
        file1_path = os.path.join(input_dir1, csv_file)
        file2_path = os.path.join(input_dir2, csv_file)
        
        if os.path.exists(file1_path) and os.path.exists(file2_path):
            # Read the column A (words) from both CSV files
            words1 = read_column(file1_path)
            words2 = read_column(file2_path)

            # Create sentences from the list of words (exclude the first word and join the rest)
            sentence1 = " ".join(words1[1:])  # Skip the first word and join the rest
            sentence2 = " ".join(words2[1:])  # Skip the first word and join the rest

            # Format the content of both CSV files as strings (including all columns)
            content1 = format_csv_content(file1_path)
            content2 = format_csv_content(file2_path)

            # Generate output file path (change extension to .txt)
            output_file = os.path.join(output_dir, f"{os.path.splitext(csv_file)[0]}.txt")

            # Write the content and sentences to the text file
            write_to_text_file(output_file, content1, content2, sentence1, sentence2)

            print(f"Processed {csv_file}. Output written to {output_file}")

def main():
    # Define the directories for input and output
    input_dir1 = '/home/pc/Desktop/Timestamps/Outputs/Output_WHLV2/csv_files'
    input_dir2 = '/home/pc/Desktop/Timestamps/Outputs/Output_WLV2/csv_files'
    output_dir = '/home/pc/Desktop/Timestamps/Collaboration'

    # Process the CSV files from both directories and generate the output files
    process_csv_files(input_dir1, input_dir2, output_dir)

if __name__ == '__main__':
    main()

