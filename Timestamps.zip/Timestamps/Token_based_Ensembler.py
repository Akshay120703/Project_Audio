import os
import csv

# Define the two input directories containing CSV files
folder1 = "/home/pc/Desktop/Timestamps/Outputs/Output_WHLV2/csv_files"
folder2 = "/home/pc/Desktop/Timestamps/Outputs/Output_WLV2/csv_files"

# Define the output text file
output_txt = "final_transcription.txt"

# Get list of CSV files in both folders
files1 = set(f for f in os.listdir(folder1) if f.endswith(".csv"))
files2 = set(f for f in os.listdir(folder2) if f.endswith(".csv"))

# Find matching files in both folders
common_files = files1.intersection(files2)

# Function to read CSV file into a list of (word, start_time, confidence)
def read_csv(file_path):
    words = []
    with open(file_path, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            word, start_time, _, confidence = row  # Ignore end time
            words.append((word, float(start_time), float(confidence)))
    return words

# Process each common CSV file
with open(output_txt, "w", encoding="utf-8") as out_file:
    for file in common_files:
        path1 = os.path.join(folder1, file)
        path2 = os.path.join(folder2, file)

        # Read words from both CSVs
        words1 = read_csv(path1)
        words2 = read_csv(path2)

        # Merge words based on start time difference ≤ 0.1s
        final_tokens = []
        used_words2 = set()  # To avoid duplicate matching

        for word1, start1, conf1 in words1:
            best_match = (word1, conf1)  # Default to word1
            for i, (word2, start2, conf2) in enumerate(words2):
                if abs(start1 - start2) <= 0.16 and i not in used_words2:
                    if conf2 > best_match[1]:  # Compare confidence
                        best_match = (word2, conf2)
                    used_words2.add(i)
                    break  # Move to next word1 after a match

            final_tokens.append((best_match[0], start1))  # Store word & start time

        # Sort words by start time
        final_tokens.sort(key=lambda x: x[1])

        # Extract only words and write to file
        audio_name = os.path.splitext(file)[0]  # Remove .csv extension
        final_text = f"{audio_name}: " + " ".join([word for word, _ in final_tokens])
        out_file.write(final_text + "\n")

print(f"✅ Processing complete! Final transcription saved in {output_txt}")

