import subprocess
import os
import sys

# ========== Path to the Python Environment ==========
# Adjust the path to your virtual environment activation script
python_env_path = "/home/pc/Desktop/Timestamps/Whisper_Timestamps/timestamped/bin/activate"

# ========== Path to the Python Scripts ==========
# Paths to the individual scripts you want to run
script_paths = [
    "/home/pc/Desktop/Timestamps/Whisper_Timestamps/whisper-timestamped/WHLV2_script.py",
    "/home/pc/Desktop/Timestamps/Whisper_Timestamps/whisper-timestamped/organizer_WHLV2.py",  # Example second script
    "/home/pc/Desktop/Timestamps/Whisper_Timestamps/whisper-timestamped/WLV2_script.py",    # Example third script
    "/home/pc/Desktop/Timestamps/Whisper_Timestamps/whisper-timestamped/organizer_WLV2.py"   # Example fourth script
]

# ========== Function to Activate the Environment and Run Scripts ==========
def activate_and_run_scripts():
    try:
        # Activate the Python environment and run the scripts sequentially
        for script_path in script_paths:
            print(f"Running script: {script_path}")

            # Use '.' instead of 'source' to activate the virtual environment in non-interactive shells
            command = f". {python_env_path} && python {script_path}"

            # Execute the command to activate the environment and run the script
            subprocess.run(command, shell=True, check=True)

            print(f"Completed running: {script_path}\n")
    
    except subprocess.CalledProcessError as e:
        print(f"Error occurred while running the script: {e}")
        sys.exit(1)

# ========== Main ==========
if __name__ == "__main__":
    print("Starting the master script...")
    activate_and_run_scripts()
    print("All scripts executed successfully.")

