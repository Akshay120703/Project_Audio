import os
import json
import csv

# Input directory containing JSON files
input_dir = "/home/pc/Desktop/Timestamps/Outputs/Output_WHLV2/json_files"
output_dir = "/home/pc/Desktop/Timestamps/Outputs/Output_WHLV2"

# Output directory for CSV files
output_dir = os.path.join(output_dir, "csv_files")
os.makedirs(output_dir, exist_ok=True)  # Create directory if it doesn't exist

# Process each JSON file in the input directory
for filename in os.listdir(input_dir):
    if filename.endswith(".json"):  # Only process JSON files
        json_path = os.path.join(input_dir, filename)
        
        # Read JSON file
        with open(json_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        # Extract words data
        words_data = []
        for segment in data.get("segments", []):
            for word in segment.get("words", []):
                words_data.append([
                    word["text"],
                    word["start"],
                    word["end"],
                    word["confidence"]
                ])

        # Define output CSV file path
        csv_filename = filename.replace(".json", ".csv")  # Replace extension
        csv_path = os.path.join(output_dir, csv_filename)

        # Write data to CSV
        with open(csv_path, "w", newline="", encoding="utf-8") as csv_file:
            writer = csv.writer(csv_file)
            writer.writerow(["Word", "Start Time", "End Time", "Confidence"])  # Header
            writer.writerows(words_data)

        print(f"Saved: {csv_path}")

print("✅ CSV extraction complete!")

